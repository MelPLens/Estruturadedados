/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ac2EstruturadeDados;


public class noAc2 {

    static int temp_no;
  int valor;
  noAc2 prox;
  noAc2 (int noAc2)  {
      valor= noAc2;
      prox = null;
  }
}
