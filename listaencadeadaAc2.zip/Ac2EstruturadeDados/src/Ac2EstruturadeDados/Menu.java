
package Ac2EstruturadeDados;


import javax.swing.JOptionPane;



//1 - inserir elemento na lista (possibilitar ao usuário que ele insira no início, no fim ou em uma posição definida)

//2 - exibir elementos da lista (exibir também a soma, média dos elementos, o maior e o menor valor (incluindo a posição))

//3 - exibir o primeiro e último elemento da lista (incluindo a posição)

//4 - funcionalidade/aplicação será proposta pelo grupo (precisa ser diferente das funcionalidades já implementadas)

public class Menu {

 
  noAc2 primeiro,ultimo;
  int numero_nos=0;
  
  Menu(){
      primeiro=ultimo=null;
  }
    
    public static void main(String[] args) {
       
        ListaEncadeada l = new ListaEncadeada();
        int opcao = 1, valor, posicao;
	while (opcao != 0) { 
		opcao = Integer.parseInt (JOptionPane.showInputDialog(null, 
                        "Escolha uma Opçao \n" 
                        + "1 - Inserir elemento na lista  \n"  
                        + "2 - Exibir elementos da lista \n" 
                        + "3 - Exibir o primeiro e último elemento da lista\n" 
                        + "4 - Exibir media dos elementos \n"+
                          "0 - Sair \n","Menu",JOptionPane.INFORMATION_MESSAGE));
                
                
		switch (opcao) {
		case 1 :
			valor = Integer.parseInt (JOptionPane.showInputDialog(null, "Insira o elemento na lista \n" + 
			"Digite um valor"));
			l.inserirNoinicio(new noAc2(valor));
			break;
		case 2 :
			valor = Integer.parseInt (JOptionPane.
			showInputDialog(null, "Exibir elementos da lista \n" +
			"Digite um valor"));
			l.inserirNofim(new noAc2(valor));
			break;
		case 3 :
			valor = Integer.parseInt (JOptionPane.showInputDialog(null, 
                                "Exibir o primeiro e último elemento da lista\n"));
                        posicao = Integer.parseInt (JOptionPane.showInputDialog(null, "Digite a posição"));
                        l.exibirPrimeiroUltimo(new noAc2(valor),posicao);
			break;
		case 4:
			valor = Integer.parseInt (JOptionPane.showInputDialog(null, "Exibir media dos elementos\n" + 
                                "Digite um valor"));
			l.mediadosno(valor);
		break;
                case 0:
			valor = Integer.parseInt (JOptionPane.showInputDialog(null, "Sair\n" + "0 - Sim\n" + "1 - Não\n",
                                 "Menu",JOptionPane.INFORMATION_MESSAGE));
			opcao=valor;
		default : JOptionPane.showMessageDialog(null,"Até Mais!");
            }
                
        }
        
    
    }
}

    