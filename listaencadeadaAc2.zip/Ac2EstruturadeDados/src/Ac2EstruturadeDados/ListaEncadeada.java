package Ac2EstruturadeDados;

import javax.swing.JOptionPane;

public class ListaEncadeada {

    noAc2 primeiro, ultimo;
    int numero_nos = 0;

    ListaEncadeada() {
        primeiro = ultimo = null;
    }

    //1 - inserir elemento na lista (possibilitar ao usuário que ele insira no início, no fim ou em uma posição definida)
    void inserirNofim(noAc2 novoNo) {
        novoNo.prox = null;
        if (primeiro == null) {
            primeiro = novoNo;
        }
        if (ultimo != null) {
            ultimo.prox = novoNo;
        }
        ultimo = novoNo;
        numero_nos++;

    }

    //2 - exibir elementos da lista (exibir também a soma, média dos elementos, o maior e o menor valor (incluindo a posição))
    void exibeLista() {
        noAc2 temp_no = primeiro;
        int i = 0;
        while (temp_no != null) //for diferente ou igual a null
        {
            System.out.println("Saida - Valor" + temp_no.valor + " posição " + i);
            temp_no = temp_no.prox;
            i++;
        }
    }

    //3 - exibir o primeiro e último elemento da lista (incluindo a posição)
    void inserirNoinicio(noAc2 novoNo) {
        novoNo.prox = primeiro;
        if (primeiro == null && ultimo == null) //Só tem um elemento na lista
        {
            ultimo = novoNo;
        }
        primeiro = novoNo;
        numero_nos++;
    }

    int ContarNos() {
        int tamanho = 0;
        noAc2 temp_no = primeiro;
        while (temp_no != null) {
            tamanho++;
            temp_no = temp_no.prox;
        }
        return tamanho;
    }

    void exibirPrimeiroUltimo(noAc2 novoNo, int posicao) {
        noAc2 temp_no = primeiro;
        int numero_nos = ContarNos();
        int pos_aux;
   
        if (primeiro == null) {
            System.out.println("A lista está vazia.");
        } else {
            System.out.println("Primeiro elemento: " + primeiro.valor + ", posição: 0");
        }
    }

    public void getLast() {
        if (ultimo == null) {
            System.out.println("A lista está vazia.");
        } else {
            int position = - 1;
            System.out.println("Último elemento: " + ultimo.valor + ", posição: " + position);
        }
  
}
        
 
//4 - funcionalidade/aplicação será proposta pelo grupo (precisa ser diferente das funcionalidades já implementadas)
    void mediadosno(int valor) {
        noAc2 temp_no = primeiro;
        noAc2 anterior_no = null;

        while (temp_no != null) {
            valor += temp_no.valor;
            numero_nos++;
            valor = noAc2.temp_no;
        }
    }

}
