/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package filajava;

import javax.swing.JOptionPane;

/**
 *
 * @author bruno
 */
public class Exercicio4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Fila F = new Fila(20);
        int valor, opcao;
        //Entrada de dados
        JOptionPane.showMessageDialog(null, 
                "Bem-vindo ao Gerenciador de Processos");
        do{
            opcao = Integer.parseInt(JOptionPane.showInputDialog(
                        "Informe a opção desejada:\n"
                        + "1 - Incluir processo na fila\n"
                        + "2 - Exibir os processos aguardando execução\n"
                        + "3 - Remover processo da fila\n"
                        + "4 - Sair"));
            switch(opcao){
                case 1:
                    if(!F.cheia()){
                        valor = Integer.parseInt(JOptionPane.showInputDialog(
                            "Informe o número do processo a ser inserido na fila:"));
                        F.enfileirar(valor);
                    }else{
                        JOptionPane.showMessageDialog(null, "FILA ESTÁ CHEIA.");
                    }
                    break;
                case 2:
                    if(!F.vazia()){
                        F.exibeFila();
                    }else{
                        JOptionPane.showMessageDialog(null, "FILA ESTÁ VAZIA.");
                    }
                    break;
                case 3:
                    if(!F.vazia()){
                        valor = Integer.parseInt(F.desenfileirar());
                        JOptionPane.showMessageDialog(null, "O processo " + valor + " foi removido da fila!");
                    }else{
                        JOptionPane.showMessageDialog(null, "FILA ESTÁ VAZIA.");
                    }
                    break;
                case 4:
                    JOptionPane.showMessageDialog(null, "O gerenciador será encerrado.");
                    break;
            }
        }while(opcao!=4);
    }
    
}
