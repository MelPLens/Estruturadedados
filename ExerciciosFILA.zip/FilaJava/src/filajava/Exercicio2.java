/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package filajava;

import javax.swing.JOptionPane;

/**
 *
 * @author bruno
 */
public class Exercicio2 {
    
    public static int maior(Fila f){
        int valor;
        int maior = Integer.parseInt(f.desenfileirar());
        while(!f.vazia()){
            valor=Integer.parseInt(f.desenfileirar());
            if (valor>maior){
                maior = valor;
            }
        }
        return maior;    
    }
    public static int menor(Fila f){
        int valor;
        int menor = Integer.parseInt(f.desenfileirar());
        while(!f.vazia()){
            valor=Integer.parseInt(f.desenfileirar());
            if (valor<menor){
                menor = valor;
            }
        }
        return menor;  
    }
    public static int media(Fila f){
        int valor, qtdElem=0, soma=0;
        while(!f.vazia()){
            valor=Integer.parseInt(f.desenfileirar());
            qtdElem++;
            soma+=valor;
        }
        return (soma/qtdElem);
        
    }

    public static void main(String[] args) {
        Fila F = new Fila(10);
        Fila F2 = new Fila(10);
        Fila F3 = new Fila(10);
        
        int valor;
      
        while(!F.cheia()){
            valor = Integer.parseInt(JOptionPane.showInputDialog(
                    "Informe o valor a ser inserido na fila:"));
            if (valor==0)
                break;
            F.enfileirar(valor);
            F2.enfileirar(valor);
            F3.enfileirar(valor);
            
        }
        JOptionPane.showMessageDialog(null, 
                "O maior valor é:" + maior(F));
        JOptionPane.showMessageDialog(null, 
                "O menor valor é:" + menor(F2));
        JOptionPane.showMessageDialog(null, 
                "A media dos valores é:" + media(F3));
    }
    
}
