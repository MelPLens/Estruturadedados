/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package filajava;

import javax.swing.JOptionPane;

/**
 *
 * @author bruno
 */
public class FilaJava {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int valor=1;
        Fila F = new Fila(10);
        while(valor!=0){
            valor =Integer.parseInt(JOptionPane.showInputDialog("Informe um valor inteiro para ser adicionado na fila:"));
            if (valor==0){
                break;
            }
            else{
                F.enfileirar(valor);
            }
        }
        System.out.println("Removendo um elemento...");
        F.desenfileirar();
        System.out.println("Os valores existem na Fila são:");
        F.exibeFila();
    }
    
}
