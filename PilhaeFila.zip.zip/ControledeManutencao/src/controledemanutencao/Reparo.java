
package controledemanutencao;

public class Reparo {

    private Veiculo veiculo;
    private String descricao;

    public Reparo(Veiculo veiculo, String descricao) {
        this.veiculo = veiculo;
        this.descricao = descricao;
    }

    public Veiculo getVeiculo() {
        return veiculo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setVeiculo(Veiculo veiculo) {
        this.veiculo = veiculo;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

   
}

