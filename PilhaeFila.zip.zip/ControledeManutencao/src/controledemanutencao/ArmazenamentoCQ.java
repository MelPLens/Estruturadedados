
package controledemanutencao;

import javax.swing.JOptionPane;


public class ArmazenamentoCQ {

   
    public static void main(String[] args) {
      

    
       PilhaCQ p = new PilhaCQ(4);
       PilhaCQ pCopy=new PilhaCQ(4); //copia
       String body;
       boolean achou=false;
       
       
       do{
       body =JOptionPane.showInputDialog(null,
               "Informe "
               + " o Body do veiculo que entrou no galpao do CQ");  //nao precisa converter pois input retorna string
      if(body.equals("Sair")) //senao sair
        
        break; 
      
      
      
    else
      p.empilhar(body); // empilhar
      pCopy.empilhar(body);
      }while(!p.cheia()); //enqunato estiver cheia
       
    
      String buscaBody = JOptionPane.showInputDialog(
                "Digite o body do carro "+
                "que deseja visualizar o status:");
        
        //desempilhar
    while(!pCopy.vazia()){
        body =String.valueOf(pCopy.desempilhar());
        if(body.equals(buscaBody))
            achou=false;// se encontrei ou não o body do carro nessa pilha
        achou=true;
        break;
   
    }
    if(achou){
         while(!p.vazia()){
         body =String.valueOf(p.desempilhar());
         if(body.equals(buscaBody))
           
        break;// quando encontra
        
        //se não encontrei
        else
            JOptionPane.showMessageDialog(null,
                    "O carro"+
                    " que foi retirado para ir ao reparo foi: " + body);
         }
    
}
        
    else{
          JOptionPane.showMessageDialog(null,
                  "O carro com o"+
                  "body digitado não esta no galpao");
    }
            
            
    }
}


    
    

