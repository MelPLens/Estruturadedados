
package controledemanutencao;

import javax.swing.JOptionPane;


public class PilhaCQ {
    


     //Declarando os atributos da classe
    int topo; // armazena o topo da pilha
    int tamanho; // tamanho da pilha
    Object vetor[]; // usado como a pilha e armazanada no vetor "array"
                   //object é um coringa pq aceita qualuer tipo de elemento 
                   //não quero que seja especifica de um tipo de dado, para evitar a troca do tipo
                    //para facilitar
    
    
    // metodo construtor : mesmo nome da classe
    // acionado quando cria um objeto
    //padrao de estrutura de uma pilha
    PilhaCQ(int tam){
        topo = -1; //Marca que a pilha está vazia
        tamanho = tam;
        vetor = new Object[tam]; // quantos elementos tera
    }
    
    //METODOS
    
    //verificar se a pilha esta vazia
    public boolean vazia(){  //se o topo é -1 ( verificar se esta vazia)
        if (topo == -1)
            return true; // retorna se tiver vazia true
        else
            return false; // se não falso
    }
    
    
    public boolean cheia(){ // cada vez que coloca
        if(topo == tamanho -1) //5 -1 = 4  0,1,2,3,4(topo)
            return true;
        else
            return false;
        //sugestao  if(p.cheia())
    }
    
    
    public void empilhar(Object elem){ // coringa
        if (cheia() == false){ // antes de empilhar verificar se esta cheia
            topo++; // implemnto o topo
            vetor[topo]=elem;// adiciona o elemento no arrat
        }
        else{ // caso ao contrario
            JOptionPane.showMessageDialog(null, 
                    "PILHA CHEIA!");
        }
    }
    
    
    public Object desempilhar(){ // o object é o tipo do retorno
        Object valorDesempilhado;
        if(vazia() == true){ // verificar se esta vazia para desempilhar
            valorDesempilhado = "Pilha Vazia";
        }
        else{ //se caso não
            valorDesempilhado = vetor[topo]; //pega o elmento do topo e joga na no topo
            topo--;
        }
        return valorDesempilhado; // retorna valor desempilhado
    }
    public void ExibePilha(){
        if(vazia() == true){ // verifica se esta vazia ante de exibir
            JOptionPane.showMessageDialog(null, 
                    "PILHA VAZIA!");
        }
        else{ // se não estiver vazia
            for(int i=topo; i>=0; i--){ // vai correr pela pilha for comrca do topo e depois 0 " no fim para o inicio" "i-- inclemneta o i" - do topo para base
                System.out.println("Elemento " 
                        + vetor[i] + " - posição " + i);
            }
        }
    }

    void ExibirPilha() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}



