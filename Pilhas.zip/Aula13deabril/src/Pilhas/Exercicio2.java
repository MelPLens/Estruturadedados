
package Pilhas;

import javax.swing.JOptionPane;

public class Exercicio2 {
//Construa um programa em JAVA utilizando uma pilha que resolva o
//seguinte problema:
//Armazene as placas dos carros que estão estacionados numa rua sem saída
//estreita. Dado uma placa verifique se o carro está estacionado na rua. Caso
//esteja, informe a sequência de carros que deverá ser retirada para que o carro
//em questão consiga sair.

    
    public static void main(String[] args) {
       Pilha p = new Pilha(10);
       Pilha pCopy=new Pilha(10); //copia
       String placa;
       boolean achou=false;
       
       
       do{
       placa =JOptionPane.showInputDialog("Informe "
               + " placa do veículo");  //nao precisa converter pois input retorna string
    if(placa.equals("Sair"))
        
        break;
    else
    p.empilhar(placa); // empilhar
    pCopy.empilhar(placa);
}while(!p.cheia());
       
        String buscaPlaca = JOptionPane.showInputDialog("Qual a placa do carro"+
                "que irá sair da rua:");
        
        //desempilhar
    while(!pCopy.vazia()){
        placa =String.valueOf(pCopy.desempilhar());
        if(placa.equals(buscaPlaca))
            achou=true;// se encontrei ou não a placa nessa pilha
        achou=true;
        break;
   
    }
    if(achou){
         while(!p.vazia()){
        placa =String.valueOf(p.desempilhar());
        if(placa.equals(buscaPlaca))
           
        break;// quando encontra
        
        //se não encontrei
        else
            JOptionPane.showMessageDialog(null,"O carro"+
                    " a ser removido é :" + placa);
         }
    
}
        
    else{
          JOptionPane.showMessageDialog(null,"O carro com a"+
                    "placa informada não esta na rua");
    }
            
            
    }
}

