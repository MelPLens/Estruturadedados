
package Pilhas;

import javax.swing.JOptionPane;


public class Exercicio3 {
//Faça uma adaptação em seu programa que manipula pilhas para que possa
//exibir o número de elementos da pilha que possuem valor par.
   
    public static void main(String[] args) {
        Pilha p = new Pilha(10);
        int num;
        int qtdPares = 0;
        
        for(int i=0;i<0;i++){
        
        num=Integer.parseInt(JOptionPane.showInputDialog("Digite"+
                "um numéro inteiro:"));
        if(num==0)
        break;
        
        else
            p.empilhar(num);
    }
        while(!p.vazia()){
            num=Integer.parseInt(String.valueOf(p.desempilhar()));
            if(num%2==0){
                qtdPares +=1;
            }   
          
    JOptionPane.showMessageDialog(null, " A Quantidade"+
            "de umeros pares é:" + qtdPares);
        }
    }
}
    