
package Pilhas;

// java main class:quando executamos no run file

import javax.swing.JOptionPane;

public class Exercicio1 {
  //Escreva um programa em JAVA que leia números inteiros e armazene em
      //uma pilha. A entrada de dados deve ser interrompida quando o usuário
      //informar o número zero e/ou esgotar a quantidade definida de elementos a
      //serem armazenados na estrutura. Por último, imprima os elementos na
      //ordem em que foram removidos da pilha.

   
    public static void main(String[] args) {
    Pilha p = new Pilha(10);
    int num;
    
    do{
    num=Integer.parseInt(JOptionPane.showInputDialog("Informe"
            + "um valor inteiro para adicionar na pilha"));
    
    if(num==0)
     break;

    else
        p.empilhar(num);
    
    }while(!p.cheia()); // operador logico ( enquanto a pilha não(!) esta cheia
    p.ExibirPilha();
    }
}
    