
package Pilhas;

import javax.swing.JOptionPane;


public class Exercicio4 {
//Escreva um programa em JAVA que cria 2 pilhas (N e P) e solicita ao usuário
//para informar números inteiros para preencher um array. Para cada valor do
//array:
//se positivo, inserir na pilha P;
//se negativo, inserir na pilha N;
//se zero, retirar um elemento de cada pilha.
//O array de números inteiros deve ter 8 elementos.

    
    public static void main(String[] args) {
       Pilha P= new Pilha(5);
       Pilha N= new Pilha(5);
       int[]numeros = new int[8];
       
       for(int i=0;i<8;i++){
           numeros[i]=Integer.parseInt(JOptionPane.showInputDialog("Informe "
           + "um numero inteiro:"));
           
           if(numeros[i]>=0){
               P.empilhar(numeros[i]);
           }else if(numeros[i]<0){
               N.empilhar(numeros[i]);
           }else
               P.desempilhar();
               N.desempilhar();
       }
       System.out.println("Valores existentes na Pilha P:");
       P.ExibePilha();
       System.out.println("Valores existentes na Pilha N:");
       N.ExibePilha();
    }
    
}
