
package Exercicio3;

//3) Escreva um programa em JAVA que crie e preencha uma pilha e remova os
//elementos da pilha e coloque na lista encadeada e na sequência imprima os
//elementos existentes na lista.
public class ListaEncadeada {
    
}
