
package Exercicio2;


public class NoSimples {
    int valor;
    NoSimples prox;
    NoSimples(int ValorNo){
        valor = ValorNo;
        prox = null;
    }
    }
 
