
package exemplolista;

import javax.swing.JOptionPane;


public class ListaEncadeada {
    IntNoSimples primeiro, ultimo;
    int numero_nos=0;
    
    ListaEncadeada(){
        primeiro = ultimo = null;   
    }
    void insereNo_fim (IntNoSimples novoNo){ // inserir no fim
	novoNo.prox = null; // percorrer até encontrar null
        if (primeiro == null) // se primeiro for igual a null
            primeiro = novoNo; //null vai ser o novo no
	if (ultimo != null) // se o ultimo for diferente de null
            ultimo.prox = novoNo; // o ultimo sera o novo no
        ultimo = novoNo; 
	numero_nos++;// contando os nos
    }
    void insereNo_inicio (IntNoSimples novoNo){
        novoNo.prox = primeiro;
	if(primeiro == null && ultimo==null) //Só tem um elemento na lista
        { // se primeiro for diferente de null e o otimo for diferente de null
            ultimo = novoNo; // o ultimo sera novo no
	}
	primeiro = novoNo; // se nao o primeiro sera o novo no
        numero_nos++; // contando os nos
    }
    int ContarNos(){ // contagem de nos 
	int tamanho = 0;
        IntNoSimples temp_no = primeiro;// crie no e pega referencia do 1 elemento
    	while (temp_no != null)//percorrer ate encontrar null
        {   tamanho++;// cada novo no contabiliza
            temp_no = temp_no.prox; // acessei o no , acessa o proximo
	}
        return tamanho;
    }
    void insereNo_posicao(IntNoSimples novoNo, int posicao){ // inserir no no final,incio ou meio
	IntNoSimples temp_no = primeiro;
	int numero_nos = ContarNos();
	int pos_aux;
	if(posicao == 0) // se colocar no 0 
	{
            novoNo.prox = primeiro; // é no primeiro
            if(primeiro == ultimo)
            {
                ultimo = novoNo;
            }
            primeiro = novoNo;
        }
        else
	{
            if (posicao <= numero_nos)// se nao for primeiro =  meio
            {   
		pos_aux = 1;
		while(temp_no != null && posicao > pos_aux)
		{
                    temp_no = temp_no.prox;
                    pos_aux ++;
                }
                novoNo.prox = temp_no.prox;
                temp_no.prox = novoNo;
            }
            else // condicao
            {
                if(posicao > numero_nos) // maior que o numero de nos
		{
                    ultimo.prox = novoNo;
                    ultimo = novoNo;
		}
            }	 
        }
    }


    IntNoSimples buscaNo (int buscaValor){ // buscar valor na lista, correr a lista para ver o valor
        int i = 0;
        IntNoSimples temp_no = primeiro; //  cria no temporario que recebe primeiro elemento da lista
        while (temp_no != null)
        {
            if (temp_no.valor == buscaValor) // o valor que estou acessando é igual que tenho na lista
            { // encontrar o valor que eu  quero
                JOptionPane.showMessageDialog(null, "No " + temp_no.valor + " posição " + i);
                return temp_no;	
            }
            i++;
            temp_no = temp_no.prox;// sempre depois do while =  temp no agora é o proximo valor
        }
        return null;
    }
    void excluiNo (int valor){
        IntNoSimples temp_no = primeiro;
        IntNoSimples anterior_no=null;// variavel para saber qual é o no  anterior
        while (temp_no != null && temp_no.valor != valor){ //percorre ate o fim da lista e verifica se encontrou o valor
            anterior_no = temp_no;// cada no armazeno commo no anterior
            temp_no = temp_no.prox;// pegar o proximo
        }
        if (temp_no == primeiro){ // verificar se o no é o primeiro da lista
            if (temp_no.prox !=null)// existe alguem depois
                primeiro = temp_no.prox; // prox é o primeiro
            else
                primeiro = null;// se nao tiver prox - coloco null
        }
        else{ // se ele nao for o primeiro da lista
            anterior_no.prox =temp_no.prox; // pega o anterior  e atribuir prx de quem quero remover   20   30    40  atribui o prox do 30(para remover o 30)
        }
        
        if (ultimo == temp_no)// se o utlimo é que eu quero remover
            ultimo = anterior_no;// o ultimo passa apontar para o anterior
    }
    void exibeLista(){
        IntNoSimples temp_no = primeiro; //temp_no = primeiro; ( primeiro lugar da lista) no temporario
        int i = 0;
        while (temp_no != null)//enquanto esse no for diferente de null
        {
            System.out.println("Saida - Valor" + temp_no.valor + " posição " + i);
                            temp_no = temp_no.prox;
            i++;
            //temp_prox - consultar o proximo 7, quando nao tem o prox dentro tem
            //null, por isso temp_no != null.
            //temp_no = temp_no.prox;  :  conferindo até chegar a null
        }
    }
}
